package com.lunyx.clashai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var elixir: EditText
    private lateinit var enemy: EditText
    private lateinit var situation: Spinner
    private lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(42, 36, 42, 36)
            setBackgroundColor(Color.rgb(15, 17, 29))
        }
        fun label(value: String, size: Float = 15f) = TextView(this).apply {
            text = value; textSize = size; setTextColor(Color.WHITE); setPadding(0, 12, 0, 8)
        }
        fun field(hint: String, value: String = "") = EditText(this).apply {
            this.hint = hint; setText(value); setTextColor(Color.WHITE); setHintTextColor(0xFF9DA3B8.toInt())
            setSingleLine(true); setPadding(18, 10, 18, 10); setBackgroundColor(0xFF252A40.toInt())
        }
        root.addView(label("LUNYX CLASH AI", 27f))
        root.addView(label("Asistente estratégico · Android sin root"))
        root.addView(label("1. Tu elixir actual (0–10)"))
        elixir = field("Ej. 6", "5"); root.addView(elixir, match())
        root.addView(label("2. Cartas o amenazas que ya mostró el rival"))
        enemy = field("Ej. Cementerio, Globo, Montapuercos…"); root.addView(enemy, match())
        root.addView(label("3. Estado de la partida"))
        situation = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Tiempo normal", "Doble elixir", "Voy ganando", "Voy perdiendo"))
        }
        root.addView(situation, match())
        root.addView(Button(this).apply {
            text = "ANALIZAR JUGADA"
            setOnClickListener { analyze() }
        }, match())
        result = label("Aquí aparecerán las recomendaciones. Introduce lo que observas en la partida.")
        result.setTextColor(0xFFE4E7F2.toInt()); root.addView(result)
        root.addView(Button(this).apply {
            text = "Permitir ventana flotante"
            setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        }, match())
        root.addView(Button(this).apply {
            text = "Mostrar recomendación flotante"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    val advice = StrategyEngine.advise(elixir.text.toString(), enemy.text.toString(), situation.selectedItem.toString())
                    startService(Intent(this@MainActivity, OverlayService::class.java).putExtra("advice", advice))
                }
            }
        }, match())
        root.addView(label("Esta versión no captura ni interpreta automáticamente la pantalla y no toca el juego. Tú introduces los datos visibles. No garantiza victorias.", 12f))
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
    }
    private fun analyze() {
        result.text = StrategyEngine.advise(elixir.text.toString(), enemy.text.toString(), situation.selectedItem.toString())
    }
    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 }
}
