package com.lunyx.clashai

/** Heurísticas transparentes: no juega ni interactúa con Clash Royale. */
object StrategyEngine {
    fun advise(elixirText: String, enemy: String, situation: String): String {
        val elixir = elixirText.toIntOrNull()?.coerceIn(0, 10) ?: 5
        val threats = enemy.lowercase()
        val advice = when {
            listOf("globo", "balloon").any { it in threats } -> "Contra Globo: guarda una defensa aérea (Mosquetera, Arqueras o edificio adecuado). Evita gastar tu respuesta aérea antes del ataque."
            listOf("cementerio", "graveyard").any { it in threats } -> "Contra Cementerio: reserva una respuesta de área (Veneno, Flechas, Valquiria o similar) y defiende junto a tu torre."
            listOf("gigante", "golem", "pekka", "megacaballero", "mega knight").any { it in threats } -> "Contra tanque: defiende primero y busca una unidad de daño alto o estructura; no apoyes un ataque si quedas sin elixir."
            listOf("montapuercos", "hog").any { it in threats } -> "Contra Montapuercos: identifica su ciclo y conserva tu edificio o respuesta principal. Cambia la colocación para evitar hechizos de valor."
            else -> "Identifica la condición de victoria rival y conserva una respuesta específica. Busca intercambios positivos de elixir antes de atacar."
        }
        val economy = when {
            elixir <= 2 -> "Elixir bajo ($elixir/10): juega barato y evita comprometerte; defiende lo imprescindible."
            elixir <= 5 -> "Elixir medio ($elixir/10): responde al rival y evita iniciar un ataque caro sin ventaja."
            elixir <= 8 -> "Elixir favorable ($elixir/10): puedes preparar un contraataque si tu defensa sobrevive."
            else -> "Elixir casi lleno ($elixir/10): evita llegar a 10; realiza una jugada segura que no te deje indefenso."
        }
        val context = when (situation) {
            "Voy ganando" -> "Protege la ventaja: prioriza defensa y no regales hechizos de valor."
            "Voy perdiendo" -> "Necesitas presión calculada: busca una oportunidad de contraataque, sin regalar una torre."
            "Doble elixir" -> "En doble elixir puedes construir pushes, pero conserva respuestas para la condición de victoria rival."
            else -> "En tiempo normal, prioriza conocer el mazo rival y el ciclo de sus cartas."
        }
        return "$advice\n\n$economy\n\n$context\n\nNota: consejo heurístico; verifica siempre la situación real de la partida."
    }
}
