package com.lunyx.clashai

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {
    private var wm: WindowManager? = null
    private var panel: TextView? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val advice = intent?.getStringExtra("advice") ?: "Abre Lunyx y analiza una jugada."
        if (panel == null) createPanel()
        panel?.text = "LUNYX AI · CONSEJO\n\n$advice\n\nToca para cerrar"
        return START_NOT_STICKY
    }
    private fun createPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        panel = TextView(this).apply {
            textSize = 13f; setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(0xEE171A2B.toInt())
            setPadding(22, 18, 22, 18); setOnClickListener { stopSelf() }
        }
        val type = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 160; width = (resources.displayMetrics.widthPixels * 0.78f).toInt() }
        wm?.addView(panel, params)
    }
    override fun onDestroy() { panel?.let { wm?.removeView(it) }; panel = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
