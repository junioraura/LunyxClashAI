# Lunyx Clash AI — prototipo Android 0.2

Aplicación nativa Kotlin para Android (minSdk 26 / Android 8+), sin root. Incluye una pantalla de asistente estratégico, heurísticas básicas transparentes y una ventana flotante que muestra el consejo generado.

## Funciones incluidas
- Entrada manual del elixir actual.
- Registro manual de amenazas/cartas rivales observadas (por ejemplo, Globo, Cementerio o Montapuercos).
- Contexto de partida: tiempo normal, doble elixir, ventaja o desventaja.
- Recomendaciones heurísticas explicadas y mostrables en una ventana flotante.
- Permiso de superposición solicitado mediante los ajustes oficiales de Android.

## Limitaciones importantes
Esta versión **no captura la pantalla**, no reconoce automáticamente cartas/tropas, no estima el elixir rival, no aprende de partidas y no controla el juego. Las recomendaciones son heurísticas sencillas, no un modelo profesional y no garantizan victorias. La ventana flotante muestra el consejo que el usuario solicita desde la app.

No automatiza toques ni juega por el usuario. Respeta las reglas del juego y usa la app como asistente manual.

## Compilar el APK automáticamente
El repositorio incluye `.github/workflows/build-apk.yml`. Sube el contenido de esta carpeta a la raíz de un repositorio GitHub, abre **Actions** y ejecuta **Build Android APK**. Al terminar, descarga el artefacto `LunyxClashAI-debug-apk`; dentro estará `app-debug.apk`.

El APK debug sirve para pruebas y puede mostrar una advertencia de instalación. No es una versión firmada para distribución pública.
